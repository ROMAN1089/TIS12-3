"""Sequential execution service for coder tasks from decomposer plans."""

import json
import logging
from collections import deque

from agent.config import Config
from agent.exceptions import AgentException
from agent.models import DecomposerOutput, TaskItem
from agent.services.generator_service import GeneratorService
from agent.services.s3_service import S3Service
from agent.utils.prompts import SystemPrompts
from agent.utils.text_utils import extract_json_from_text

logger = logging.getLogger(__name__)


class CoderPlanService:
    """Executes coder tasks from an execution plan in strict sequential order."""

    def __init__(
        self,
        generator_service: GeneratorService,
        s3_service: S3Service,
        config: Config,
    ):
        self.generator = generator_service
        self.s3 = s3_service
        self.config = config

    def execute_plan(self, plan_text: str) -> tuple[str, dict]:
        """
        Execute coder tasks from decomposer plan sequentially.

        Args:
            plan_text: Raw execution plan text (JSON or text containing JSON)

        Returns:
            Tuple of (combined_python_code, execution_metadata)

        Raises:
            AgentException: If plan parsing or execution fails
        """
        plan = self._parse_plan(plan_text)
        coder_tasks = [task for task in plan.tasks if task.agent == "coder"]

        if not coder_tasks:
            raise AgentException("Execution plan contains no tasks for agent 'coder'")

        ordered_tasks = self._order_tasks_sequentially(coder_tasks)

        logger.info(
            "Coder plan execution started: total_tasks=%s, model=%s",
            len(ordered_tasks),
            self.config.ollama.model,
        )

        system_prompt, _, _, _ = SystemPrompts.build_for_role("coder")
        task_results: dict[str, dict] = {}
        completed_ids: set[str] = set()

        for task in ordered_tasks:
            missing_dependencies = [
                dep for dep in task.dependencies if dep in {t.id for t in ordered_tasks} and dep not in completed_ids
            ]
            if missing_dependencies:
                raise AgentException(
                    f"Task '{task.id}' cannot run. Missing completed dependencies: {missing_dependencies}"
                )

            task_prompt = self._build_task_prompt(task, task_results)
            generated_code, retries_used = self.generator.generate_with_retry(
                system_prompt=system_prompt,
                user_prompt=task_prompt,
                is_code=True,
                is_json=False,
            )

            artifact = self.s3.upload_artifact(
                content=generated_code,
                extension="py",
                role=f"{self.config.agent.role}/tasks",
            )

            task_results[task.id] = {
                "task_id": task.id,
                "artifact_key": artifact.s3_key,
                "artifact_url": artifact.s3_url,
                "retries_used": retries_used,
                "code": generated_code,
            }
            completed_ids.add(task.id)

            logger.info("Coder task completed: id=%s, retries=%s", task.id, retries_used)

        combined_code = self._combine_code(task_results, ordered_tasks)
        metadata = {
            "executed_task_ids": [task.id for task in ordered_tasks],
            "task_results": {
                task_id: {
                    "artifact_key": data["artifact_key"],
                    "retries_used": data["retries_used"],
                }
                for task_id, data in task_results.items()
            },
            "execution_mode": "sequential",
            "parallel": False,
        }
        return combined_code, metadata

    def is_execution_plan(self, plan_text: str) -> bool:
        """Check whether input text contains a valid decomposer execution plan."""
        try:
            self._parse_plan(plan_text)
            return True
        except AgentException:
            return False

    def _parse_plan(self, plan_text: str) -> DecomposerOutput:
        """Parse decomposer output text into DecomposerOutput model."""
        extracted = extract_json_from_text(plan_text)
        source = extracted if extracted else plan_text.strip()

        try:
            payload = json.loads(source)
        except json.JSONDecodeError as e:
            raise AgentException(f"Invalid execution plan JSON: {e}")

        try:
            return DecomposerOutput.model_validate(payload)
        except Exception as e:
            raise AgentException(f"Execution plan schema validation failed: {e}")

    def _order_tasks_sequentially(self, tasks: list[TaskItem]) -> list[TaskItem]:
        """Topologically order tasks by dependencies (sequential execution)."""
        task_map = {task.id: task for task in tasks}
        in_degree = {task.id: 0 for task in tasks}
        adjacency: dict[str, list[str]] = {task.id: [] for task in tasks}

        for task in tasks:
            for dependency in task.dependencies:
                if dependency in task_map:
                    adjacency[dependency].append(task.id)
                    in_degree[task.id] += 1

        queue = deque(sorted([task_id for task_id, degree in in_degree.items() if degree == 0]))
        ordered_ids: list[str] = []

        while queue:
            current = queue.popleft()
            ordered_ids.append(current)
            for neighbor in sorted(adjacency[current]):
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        if len(ordered_ids) != len(tasks):
            raise AgentException("Execution plan has cyclic coder dependencies")

        return [task_map[task_id] for task_id in ordered_ids]

    def _build_task_prompt(self, task: TaskItem, task_results: dict[str, dict]) -> str:
        """Build task prompt with previous dependency outputs as context."""
        prompt_parts = [
            "You are executing a single step from an execution plan.",
            f"Task ID: {task.id}",
            f"Task description: {task.input_data}",
            "Generate only the Python code for this task.",
        ]

        if task.context_keys:
            prompt_parts.append("Task context keys:")
            for key, value in task.context_keys.items():
                prompt_parts.append(f"- {key}: {value}")

        if task.dependencies:
            prompt_parts.append("Dependency outputs:")
            for dependency in task.dependencies:
                dep_result = task_results.get(dependency)
                if dep_result:
                    prompt_parts.append(f"\n--- Dependency Task {dependency} ---\n{dep_result['code']}")

        return "\n".join(prompt_parts)

    @staticmethod
    def _combine_code(task_results: dict[str, dict], ordered_tasks: list[TaskItem]) -> str:
        """Combine generated task code snippets into one artifact."""
        sections: list[str] = []
        for task in ordered_tasks:
            snippet = task_results[task.id]["code"]
            sections.append(f"# ==== TASK {task.id} ====\n{snippet.strip()}\n")
        return "\n".join(sections).strip() + "\n"