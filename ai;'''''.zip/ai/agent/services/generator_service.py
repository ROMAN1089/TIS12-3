"""Content generation service with automatic retry and validation."""

import logging
from typing import Callable

from agent.config import Config
from agent.constants import ValidationMode, get_validation_mode
from agent.exceptions import MaxRetriesExceededError, ValidationError
from agent.services.ollama_service import OllamaService
from agent.utils.prompts import SystemPrompts
from agent.utils.text_utils import clean_code_block, extract_json_from_text, truncate_for_logging
from agent.utils.validators import PythonValidator, JSONValidator

logger = logging.getLogger(__name__)


class GeneratorService:
    """Service for generating content with automatic validation and self-correction."""

    def __init__(self, ollama_service: OllamaService, config: Config):
        """
        Initialize generator service.

        Args:
            ollama_service: Ollama LLM service instance
            config: Application configuration
        """
        self.ollama = ollama_service
        self.config = config
        self._python_validator = PythonValidator()
        self._json_validator = JSONValidator()

    def generate_with_retry(
        self,
        system_prompt: str,
        user_prompt: str,
        is_code: bool,
        is_json: bool,
    ) -> tuple[str, int]:
        """
        Generate content with automatic retry and validation.

        Attempts to generate content up to max_retries times, validating
        against schema and self-correcting on failures.

        Args:
            system_prompt: System prompt defining agent behavior
            user_prompt: User's request/task description
            is_code: Whether output should be Python code
            is_json: Whether output should be JSON

        Returns:
            Tuple of (final_content, retries_used)

        Raises:
            MaxRetriesExceededError: If max retries exceeded with invalid output
        """
        validation_mode = get_validation_mode(is_json, is_code)
        validator = self._get_validator(validation_mode)

        messages: list[dict[str, str]] = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        last_clean = ""
        logger.info(
            f"Starting generation: validation_mode={validation_mode}, "
            f"max_retries={self.config.agent.max_retries}"
        )

        for attempt in range(self.config.agent.max_retries + 1):
            logger.info(f"Generation attempt {attempt + 1}/{self.config.agent.max_retries + 1}")

            # Generate content
            raw = self.ollama.chat(messages, force_json=is_json)
            clean = clean_code_block(raw)
            last_clean = clean

            # Try to validate
            try:
                validated = self._validate_and_extract(clean, validator, validation_mode)
                logger.info(f"✓ Validation passed on attempt {attempt + 1}")
                return validated, attempt

            except ValidationError as e:
                logger.warning(f"✗ Validation failed: {e}")

                if attempt >= self.config.agent.max_retries:
                    logger.error(
                        f"Max retries reached. Last response: "
                        f"{truncate_for_logging(clean)}"
                    )
                    raise MaxRetriesExceededError(self.config.agent.max_retries, str(e))

                # Add correction prompt for next attempt
                fix_prompt = SystemPrompts.get_error_correction_prompt(
                    validation_mode.value, str(e)
                )
                messages.append({"role": "assistant", "content": raw})
                messages.append({"role": "user", "content": fix_prompt})

        # Should not reach here due to exception above
        raise MaxRetriesExceededError(self.config.agent.max_retries, "Unknown error")

    def _get_validator(self, mode: ValidationMode) -> Callable[[str], None]:
        """Get validator function for validation mode."""
        if mode == ValidationMode.JSON:
            return self._json_validator.validate
        elif mode == ValidationMode.PYTHON:
            return self._python_validator.validate
        else:
            return lambda _: None  # No validation for generic mode

    def _validate_and_extract(
        self,
        content: str,
        validator: Callable[[str], None],
        mode: ValidationMode,
    ) -> str:
        """
        Validate content and extract/normalize if needed.

        Args:
            content: Content to validate
            validator: Validation function
            mode: Validation mode

        Returns:
            Validated/extracted content

        Raises:
            ValidationError: If validation fails
        """
        if mode == ValidationMode.JSON:
            # Try to extract valid JSON from potentially dirty response
            extracted = extract_json_from_text(content)
            if extracted:
                content = extracted

        validator(content)
        return content
