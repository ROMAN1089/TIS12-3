"""S3 storage service for artifact management."""

import io
import uuid
import logging
from datetime import datetime

import boto3
from botocore.exceptions import ClientError

from agent.config import Config
from agent.exceptions import S3BucketError, S3DownloadError, S3UploadError
from agent.models import AgentArtifact

logger = logging.getLogger(__name__)


class S3Service:
    """Service for managing S3 storage operations."""

    def __init__(self, config: Config):
        """
        Initialize S3 client and ensure bucket exists.

        Args:
            config: Application configuration

        Raises:
            S3BucketError: If bucket initialization fails
        """
        try:
            self.client = boto3.client(
                "s3",
                endpoint_url=config.s3.endpoint,
                aws_access_key_id=config.s3.access_key,
                aws_secret_access_key=config.s3.secret_key,
                region_name=config.s3.region,
            )
            self.bucket = config.s3.bucket
            self._ensure_bucket_exists()
        except Exception as e:
            raise S3BucketError(f"Failed to initialize S3 service: {e}")

    def _ensure_bucket_exists(self) -> None:
        """
        Ensure the S3 bucket exists, create if necessary.

        Raises:
            S3BucketError: If bucket operations fail
        """
        try:
            self.client.head_bucket(Bucket=self.bucket)
            logger.info(f"Connected to S3 bucket: {self.bucket}")
        except ClientError as e:
            logger.warning(f"Bucket {self.bucket} not accessible. Attempting to create...")
            try:
                self.client.create_bucket(Bucket=self.bucket)
                logger.info(f"Created bucket: {self.bucket}")
            except Exception as create_error:
                raise S3BucketError(f"Failed to create bucket {self.bucket}: {create_error}")

    def parse_s3_ref(self, ref: str) -> tuple[str, str]:
        """
        Parse S3 reference into bucket and key components.

        Accepts multiple formats:
        - s3://bucket/key
        - bucket/key
        - key (uses default bucket)

        Args:
            ref: S3 reference string

        Returns:
            Tuple of (bucket, key)

        Raises:
            ValueError: If reference format is invalid
        """
        ref = ref.strip()

        if ref.startswith("s3://"):
            no_scheme = ref[5:]  # Remove 's3://'
            parts = no_scheme.split("/", 1)
            if len(parts) != 2 or not parts[0] or not parts[1]:
                raise ValueError(f"Invalid s3:// reference: {ref}")
            return parts[0], parts[1]

        if "/" in ref and not ref.startswith("/"):
            bucket, key = ref.split("/", 1)
            if bucket == self.bucket:
                return bucket, key
            return self.bucket, ref

        return self.bucket, ref

    def download_content(self, ref: str) -> str:
        """
        Download content from S3 by reference.

        Args:
            ref: S3 reference (s3://bucket/key or key)

        Returns:
            Content as string

        Raises:
            S3DownloadError: If download fails
        """
        try:
            bucket, key = self.parse_s3_ref(ref)
            obj = self.client.get_object(Bucket=bucket, Key=key)
            return obj["Body"].read().decode("utf-8", errors="replace")
        except ValueError as e:
            raise S3DownloadError(f"Invalid S3 reference '{ref}': {e}")
        except ClientError as e:
            raise S3DownloadError(f"Failed to download from S3 '{ref}': {e}")
        except Exception as e:
            raise S3DownloadError(f"Unexpected error downloading '{ref}': {e}")

    def upload_artifact(
        self, content: str, extension: str, role: str
    ) -> AgentArtifact:
        """
        Upload artifact to S3 with timestamp and ID for uniqueness.

        Args:
            content: Content to upload
            extension: File extension (json, py, txt, md)
            role: Agent role for folder organization

        Returns:
            AgentArtifact with S3 details

        Raises:
            S3UploadError: If upload fails
        """
        try:
            # Generate unique filename with role and timestamp
            unique_id = uuid.uuid4().hex[:8]
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{role}/{timestamp}_{unique_id}.{extension}"

            # Upload to S3
            file_obj = io.BytesIO(content.encode("utf-8"))
            self.client.upload_fileobj(file_obj, self.bucket, filename)

            # Generate presigned URL for retrieval
            url = self.client.generate_presigned_url(
                "get_object",
                Params={"Bucket": self.bucket, "Key": filename},
                ExpiresIn=3600,
            )

            logger.info(f"Artifact uploaded: {filename}")

            return AgentArtifact(
                s3_key=filename,
                s3_url=url,
                content_type=extension,
                filename=filename,
            )

        except Exception as e:
            logger.error(f"S3 upload failed: {e}")
            raise S3UploadError(f"Failed to upload artifact to S3: {e}")
