"""Ollama LLM service for content generation."""

import logging
from typing import Any

import ollama

from agent.config import Config
from agent.exceptions import OllamaError
from agent.utils.text_utils import truncate_for_logging

logger = logging.getLogger(__name__)


class OllamaService:
    """Service for interacting with Ollama LLM models."""

    def __init__(self, config: Config):
        """
        Initialize Ollama service.

        Args:
            config: Application configuration

        Raises:
            OllamaError: If client initialization fails
        """
        try:
            self.client = ollama.Client(host=config.ollama.host)
            self.model = config.ollama.model
            self.temperature = config.ollama.temperature
            self.num_predict = config.ollama.num_predict
            logger.info(f"Ollama service initialized: {self.model} @ {config.ollama.host}")
        except Exception as e:
            raise OllamaError(f"Failed to initialize Ollama client: {e}")

    def chat(
        self,
        messages: list[dict[str, str]],
        force_json: bool = False,
    ) -> str:
        """
        Send chat request to Ollama and return response.

        Args:
            messages: List of message dicts with 'role' and 'content'
            force_json: Whether to request JSON output (model dependent)

        Returns:
            Generated content as string

        Raises:
            OllamaError: If chat request fails
        """
        try:
            kwargs: dict[str, Any] = {
                "model": self.model,
                "messages": messages,
                "options": {
                    "temperature": self.temperature,
                    "num_predict": self.num_predict,
                },
            }

            # Note: format="json" may cause issues with some models.
            # We rely on text extraction instead.
            # Uncomment only if your model properly supports format="json"
            # if force_json:
            #     kwargs["format"] = "json"

            response = self.client.chat(**kwargs)
            content = response["message"]["content"]

            logger.info(
                f"Generated content (length={len(content)}): "
                f"{truncate_for_logging(content)}"
            )
            return content

        except Exception as e:
            logger.error(f"Ollama chat failed: {e}")
            raise OllamaError(f"Ollama chat request failed: {e}")
