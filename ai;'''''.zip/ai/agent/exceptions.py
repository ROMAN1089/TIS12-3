"""Custom exceptions for the application."""


class AgentException(Exception):
    """Base exception for all agent-related errors."""
    pass


class ValidationError(AgentException):
    """Raised when content validation fails."""
    def __init__(self, message: str, validation_type: str = "unknown"):
        self.validation_type = validation_type
        super().__init__(message)


class JSONValidationError(ValidationError):
    """Raised when JSON validation fails."""
    def __init__(self, message: str):
        super().__init__(message, "json")


class PythonValidationError(ValidationError):
    """Raised when Python code validation fails."""
    def __init__(self, message: str):
        super().__init__(message, "python")


class GenerationError(AgentException):
    """Raised when content generation fails."""
    pass


class MaxRetriesExceededError(GenerationError):
    """Raised when maximum retry attempts are exceeded."""
    def __init__(self, max_retries: int, last_error: str):
        self.max_retries = max_retries
        self.last_error = last_error
        super().__init__(f"Max retries ({max_retries}) exceeded. Last error: {last_error}")


class S3Error(AgentException):
    """Raised when S3 operations fail."""
    pass


class S3BucketError(S3Error):
    """Raised when S3 bucket operations fail."""
    pass


class S3DownloadError(S3Error):
    """Raised when S3 download fails."""
    pass


class S3UploadError(S3Error):
    """Raised when S3 upload fails."""
    pass


class ConfigurationError(AgentException):
    """Raised when configuration is invalid."""
    pass


class OllamaError(AgentException):
    """Raised when Ollama operations fail."""
    pass


class AuthenticationError(AgentException):
    """Raised when authentication fails."""
    pass
