"""Application-wide constants and enumerations."""

from enum import Enum
from typing import Dict, Tuple


class AgentRole(str, Enum):
    """Supported agent roles."""
    DECOMPOSER = "decomposer"
    DB_ARCHITECT = "db_architect"
    CODER = "coder"
    GENERIC = "generic"


class OutputFormat(str, Enum):
    """Output format types."""
    JSON = "json"
    PYTHON = "py"
    TEXT = "txt"
    MARKDOWN = "md"


class ValidationMode(str, Enum):
    """Content validation modes."""
    NONE = "none"
    JSON = "json"
    PYTHON = "python"


# Default configuration values
DEFAULT_MAX_RETRIES = 3
DEFAULT_TEMPERATURE = 0.0
DEFAULT_NUM_PREDICT = 2048
DEFAULT_OLLAMA_MODEL = "llama3"
DEFAULT_SERVICE_ROLE = AgentRole.GENERIC.value
DEFAULT_API_TOKEN = "change_me"

# Limits
MAX_CONTENT_LENGTH = 3000  # Logging truncation limit
MAX_CONTEXT_RETRIES = 10

# Validation error patterns
TRUNCATION_PATTERNS = ["'...'", "..."]


# Role configuration mapping
ROLE_CONFIG: Dict[AgentRole, Tuple[bool, bool, OutputFormat]] = {
    AgentRole.DECOMPOSER: (False, True, OutputFormat.JSON),
    AgentRole.DB_ARCHITECT: (True, False, OutputFormat.PYTHON),
    AgentRole.CODER: (True, False, OutputFormat.PYTHON),
    AgentRole.GENERIC: (False, False, OutputFormat.TEXT),
}


def get_validation_mode(is_json: bool, is_code: bool) -> ValidationMode:
    """Determine validation mode from flags."""
    if is_json:
        return ValidationMode.JSON
    elif is_code:
        return ValidationMode.PYTHON
    return ValidationMode.NONE
