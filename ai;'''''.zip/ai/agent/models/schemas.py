"""Pydantic schemas for API requests and responses."""

from typing import Optional, Any
from pydantic import BaseModel, Field


class AgentRequest(BaseModel):
    """Request schema for agent generation."""

    input_data: str = Field(..., description="Промпт/спецификация/описание задачи")
    context_keys: Optional[dict[str, str]] = Field(
        None,
        description="Ссылки на контекст в S3: {'spec':'s3://bucket/key'} или просто 'key'",
    )
    system_prompt_override: Optional[str] = None


class AgentArtifact(BaseModel):
    """Artifact information stored in S3."""

    s3_key: str
    s3_url: str
    content_type: str
    filename: str


class AgentResponse(BaseModel):
    """Response schema for agent generation."""

    status: str
    artifact: AgentArtifact
    metadata: dict[str, Any] = Field(default_factory=dict)


class TaskItem(BaseModel):
    """Single execution plan task item for decomposer."""

    id: str
    agent: str
    input_data: str
    context_keys: dict[str, str] = Field(default_factory=dict)
    output_type: str
    dependencies: list[str]


class DecomposerOutput(BaseModel):
    """Decomposer output containing execution plan tasks."""

    tasks: list[TaskItem]
