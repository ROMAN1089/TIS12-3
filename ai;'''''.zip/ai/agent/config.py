"""Configuration management for the AI agent."""

import os
from dataclasses import dataclass
from typing import Optional
from dotenv import load_dotenv

from agent.constants import (
    DEFAULT_MAX_RETRIES,
    DEFAULT_TEMPERATURE,
    DEFAULT_NUM_PREDICT,
    DEFAULT_OLLAMA_MODEL,
    DEFAULT_SERVICE_ROLE,
    DEFAULT_API_TOKEN,
)
from agent.exceptions import ConfigurationError

load_dotenv()


@dataclass
class OllamaConfig:
    """Ollama LLM configuration."""
    model: str
    host: str
    temperature: float
    num_predict: int

    def __post_init__(self) -> None:
        """Validate configuration values."""
        if not self.model:
            raise ConfigurationError("Ollama model cannot be empty")
        if not self.host:
            raise ConfigurationError("Ollama host cannot be empty")
        if not 0.0 <= self.temperature <= 1.0:
            raise ConfigurationError(f"Temperature must be between 0.0 and 1.0, got {self.temperature}")
        if self.num_predict < 1:
            raise ConfigurationError(f"num_predict must be positive, got {self.num_predict}")


@dataclass
class S3Config:
    """S3/MinIO configuration."""
    endpoint: str
    access_key: str
    secret_key: str
    bucket: str
    region: str

    def __post_init__(self) -> None:
        """Validate configuration values."""
        if not self.endpoint:
            raise ConfigurationError("S3 endpoint cannot be empty")
        if not self.bucket:
            raise ConfigurationError("S3 bucket cannot be empty")


@dataclass
class ServerConfig:
    """Server configuration."""
    host: str
    port: int

    def __post_init__(self) -> None:
        """Validate configuration values."""
        if not self.host:
            raise ConfigurationError("Server host cannot be empty")
        if not 1 <= self.port <= 65535:
            raise ConfigurationError(f"Port must be between 1 and 65535, got {self.port}")


@dataclass
class AgentConfig:
    """Agent behavior configuration."""
    role: str
    api_token: str
    max_retries: int

    def __post_init__(self) -> None:
        """Validate configuration values."""
        if not self.api_token:
            raise ConfigurationError("API token cannot be empty")
        if self.max_retries < 0:
            raise ConfigurationError(f"max_retries must be non-negative, got {self.max_retries}")


@dataclass
class Config:
    """Application configuration."""
    agent: AgentConfig
    ollama: OllamaConfig
    s3: S3Config
    server: ServerConfig

    @classmethod
    def from_env(cls) -> "Config":
        """Load configuration from environment variables."""
        agent_role = os.getenv("AGENT_ROLE", DEFAULT_SERVICE_ROLE)
        ollama_model = os.getenv("OLLAMA_MODEL", DEFAULT_OLLAMA_MODEL)
        if agent_role == "coder":
            ollama_model = "pycode"

        agent = AgentConfig(
            role=agent_role,
            api_token=os.getenv("AGENT_SECRET_TOKEN", DEFAULT_API_TOKEN),
            max_retries=int(os.getenv("MAX_SELF_CORRECTION_RETRIES", DEFAULT_MAX_RETRIES)),
        )

        ollama = OllamaConfig(
            model=ollama_model,
            host=os.getenv("OLLAMA_HOST", "http://localhost:11434"),
            temperature=float(os.getenv("OLLAMA_TEMPERATURE", DEFAULT_TEMPERATURE)),
            num_predict=int(os.getenv("OLLAMA_NUM_PREDICT", DEFAULT_NUM_PREDICT)),
        )

        s3 = S3Config(
            endpoint=os.getenv("S3_ENDPOINT", "http://localhost:9000"),
            access_key=os.getenv("S3_ACCESS_KEY", "minioadmin"),
            secret_key=os.getenv("S3_SECRET_KEY", "minioadmin"),
            bucket=os.getenv("S3_BUCKET", "agent-artifacts"),
            region=os.getenv("S3_REGION", "us-east-1"),
        )

        server = ServerConfig(
            host=os.getenv("HOST", "0.0.0.0"),
            port=int(os.getenv("PORT", "8000")),
        )

        return cls(agent=agent, ollama=ollama, s3=s3, server=server)


# Global config instance
config = Config.from_env()
