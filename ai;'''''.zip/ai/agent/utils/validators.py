"""Content validators for Python code and JSON output."""

import ast
import json
import logging
from typing import Optional
from abc import ABC, abstractmethod

from pydantic import ValidationError

from agent.constants import TRUNCATION_PATTERNS
from agent.exceptions import JSONValidationError, PythonValidationError
from agent.models import DecomposerOutput

logger = logging.getLogger(__name__)


class Validator(ABC):
    """Abstract base class for content validators."""

    @abstractmethod
    def validate(self, content: str) -> None:
        """
        Validate content. Raises exception if invalid.

        Args:
            content: Content to validate

        Raises:
            ValidationError: If content is invalid
        """
        pass


class PythonValidator(Validator):
    """Validator for Python code syntax."""

    def validate(self, code: str) -> None:
        """
        Validate Python code syntax.

        Args:
            code: Python code to validate

        Raises:
            PythonValidationError: If code has syntax errors
        """
        try:
            ast.parse(code)
        except SyntaxError as e:
            raise PythonValidationError(
                f"SYNTAX_ERROR: Line {e.lineno}: {e.msg}\nCode: {e.text}"
            )
        except Exception as e:
            raise PythonValidationError(f"ERROR: {str(e)}")

    @staticmethod
    def validate_legacy(code: str) -> str:
        """Legacy API for backward compatibility. Use validate() instead."""
        try:
            ast.parse(code)
            return "PASS"
        except SyntaxError as e:
            return f"SYNTAX_ERROR: Line {e.lineno}: {e.msg}\nCode: {e.text}"
        except Exception as e:
            return f"ERROR: {str(e)}"


class JSONValidator(Validator):
    """Validator for JSON output conforming to schemas."""

    ALLOWED_EXECUTION_AGENTS = {"db_architect", "coder"}

    def validate(self, content: str) -> None:
        """
        Validate JSON content.

        Args:
            content: JSON content to validate

        Raises:
            JSONValidationError: If JSON is invalid
        """
        self.validate_decomposer_output(content)

    @staticmethod
    def _contains_truncation_patterns(text: str) -> bool:
        """Check if text contains obvious truncation markers."""
        return any(
            text.count(pattern) > 2 or text.endswith(pattern)
            for pattern in TRUNCATION_PATTERNS
        )

    @staticmethod
    def validate_decomposer_output(raw_text: str) -> str:
        """
        Validate JSON against DecomposerOutput execution-plan schema.

        Checks:
        - JSON is parseable
        - Schema matches DecomposerOutput
        - Dependencies refer to existing task IDs
        - No obvious truncation patterns

        Args:
            raw_text: Raw JSON text to validate

        Returns:
            Normalized JSON string if valid

        Raises:
            JSONValidationError: If validation fails
        """
        logger.info(f"Validating JSON (length={len(raw_text)}): {raw_text[:150]}...")

        # Check for truncation patterns
        if JSONValidator._contains_truncation_patterns(raw_text):
            raise JSONValidationError(
                "JSON appears to be truncated (contains '...' placeholders or ends with dots)"
            )

        # Parse JSON
        try:
            data = json.loads(raw_text)
        except json.JSONDecodeError as e:
            logger.error(f"JSON parse error: {e.msg} at line {e.lineno}, col {e.colno}. Raw text (first 300 chars): {raw_text[:300]!r}")
            raise JSONValidationError(
                f"JSON parse error at line {e.lineno}, col {e.colno}: {e.msg}"
            )

        # Try to normalize common issues (ids, agent names, context_keys, dependencies)
        try:
            data = JSONValidator._normalize_decomposer_payload(data)
        except JSONValidationError:
            # _normalize_decomposer_payload raises JSONValidationError for unrecoverable formats
            raise

        # Validate against schema
        try:
            obj = DecomposerOutput.model_validate(data)
            logger.info(f"✓ JSON validation passed: {len(obj.tasks)} tasks")
            return obj.model_dump_json()
        except ValidationError as e:
            raise JSONValidationError(f"Schema validation failed: {e}")

    @staticmethod
    def _normalize_decomposer_payload(data):
        """
        Normalize common variations of decomposer output into canonical form.

        - Accept a top-level list (wrap into {"tasks": [...]})
        - Ensure each task is a dict with required keys
        - Convert non-numeric ids to sequential numeric string ids and remap dependencies
        - Map common agent aliases to allowed agents
        - Normalize context_keys to a dict

        Raises JSONValidationError on unrecoverable formats.
        """
        # If model returned a bare list, wrap it
        if isinstance(data, list):
            data = {"tasks": data}

        if not isinstance(data, dict) or "tasks" not in data:
            raise JSONValidationError("EXPECTED_OBJECT_WITH_TASKS: No top-level 'tasks' array found")

        tasks = data.get("tasks")
        if not isinstance(tasks, list):
            raise JSONValidationError("EXPECTED_TASKS_ARRAY: 'tasks' must be a list")

        # Build id mapping
        old_ids = []
        for i, t in enumerate(tasks, start=1):
            if isinstance(t, dict) and "id" in t:
                old_ids.append(str(t["id"]))
            else:
                old_ids.append(str(i))

        id_map = {old: str(i + 1) for i, old in enumerate(old_ids)}

        # Agent alias mapping
        alias_map = {
            "DatabaseDesigner": "db_architect",
            "DomainModeler": "db_architect",
            "DomainDesigner": "db_architect",
            "Developer": "coder",
            "Engineer": "coder",
        }

        normalized_tasks = []
        for idx, raw in enumerate(tasks, start=1):
            if not isinstance(raw, dict):
                raise JSONValidationError("TASK_FORMAT_ERROR: Each task must be an object/dict")

            old_id = str(raw.get("id", old_ids[idx - 1]))
            new_id = id_map.get(old_id, str(idx))

            agent = raw.get("agent", "coder")
            if isinstance(agent, str) and agent in alias_map:
                agent = alias_map[agent]
            if agent not in JSONValidator.ALLOWED_EXECUTION_AGENTS:
                # Force default to 'coder' if unknown
                logger.warning(f"Unknown agent '{agent}' replaced with 'coder'")
                agent = "coder"

            input_data = raw.get("input_data")
            if input_data is None:
                raise JSONValidationError(f"TASK_MISSING_INPUT_DATA: task '{old_id}' has no input_data")
            input_data = str(input_data).strip()

            # Normalize context_keys: accept dict or list
            context = raw.get("context_keys", {})
            if isinstance(context, list):
                # convert list to dict with generated keys
                context = {f"ctx{i+1}": v for i, v in enumerate(context)}
            if not isinstance(context, dict):
                context = {}

            output_type = raw.get("output_type")
            if output_type is None:
                # try guess from agent
                output_type = "py" if agent == "db_architect" or agent == "coder" else "txt"
            output_type = str(output_type)

            deps = raw.get("dependencies", [])
            if deps is None:
                deps = []
            if not isinstance(deps, list):
                # attempt to coerce single value
                deps = [str(deps)]

            # Remap dependency ids if they referenced old ids
            remapped_deps = []
            for d in deps:
                d_str = str(d)
                if d_str in id_map:
                    remapped_deps.append(id_map[d_str])
                else:
                    # if it's numeric-like, keep as-is
                    remapped_deps.append(d_str)

            normalized_tasks.append(
                {
                    "id": new_id,
                    "agent": agent,
                    "input_data": input_data,
                    "context_keys": context,
                    "output_type": output_type,
                    "dependencies": remapped_deps,
                }
            )

        return {"tasks": normalized_tasks}

    @staticmethod
    def validate_decomposer_output_legacy(
        raw_text: str,
    ) -> tuple[bool, str, Optional[str]]:
        """Legacy API for backward compatibility."""
        logger.info(f"Validating JSON (length={len(raw_text)}): {raw_text[:150]}...")

        if JSONValidator._contains_truncation_patterns(raw_text):
            return False, "JSON_TRUNCATION: Response appears truncated", None

        try:
            data = json.loads(raw_text)
        except json.JSONDecodeError as e:
            return False, f"JSON_ERROR: {e.msg} at line {e.lineno}, column {e.colno}", None

        try:
            obj = DecomposerOutput.model_validate(data)
            logger.info(f"✓ JSON validation passed: {len(obj.tasks)} tasks")
            return True, "", obj.model_dump_json()
        except ValidationError as e:
            return False, f"SCHEMA_ERROR: {str(e)}", None
        except ValidationError as e:
            logger.error(f"Schema validation error: {str(e)}")
            return False, f"SCHEMA_ERROR: {str(e)}", None
        
        # Check that dependencies reference existing IDs
        ids = {t.id for t in obj.tasks}
        for task in obj.tasks:
            if task.agent not in JSONValidator.ALLOWED_EXECUTION_AGENTS:
                logger.error(
                    "Invalid agent '%s'. Allowed agents: %s",
                    task.agent,
                    ", ".join(sorted(JSONValidator.ALLOWED_EXECUTION_AGENTS)),
                )
                return (
                    False,
                    "AGENT_ERROR: invalid agent '%s'. Allowed agents: %s"
                    % (task.agent, ", ".join(sorted(JSONValidator.ALLOWED_EXECUTION_AGENTS))),
                    None,
                )
            for dep in task.dependencies:
                if dep not in ids:
                    logger.error(f"Dependency error: task '{task.id}' depends on unknown id '{dep}'")
                    return False, f"DEPENDENCY_ERROR: task '{task.id}' depends on unknown id '{dep}'", None
        
        normalized = json.dumps(obj.model_dump(), ensure_ascii=False)
        logger.info(f"JSON validation passed. Tasks: {len(obj.tasks)}")
        return True, "PASS", normalized
