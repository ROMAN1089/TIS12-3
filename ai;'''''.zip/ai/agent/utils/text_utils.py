"""Text processing and extraction utilities."""

import json
import logging
from typing import Optional

logger = logging.getLogger(__name__)

MARKDOWN_CODE_FENCE = "```"


def clean_code_block(text: str) -> str:
    """
    Extract raw content from markdown fenced code blocks.

    Handles triple-backtick markdown code blocks (```language...```).
    If no code block found, returns text as-is.

    Args:
        text: Input text possibly containing markdown code blocks

    Returns:
        Cleaned text without markdown formatting

    Example:
        >>> clean_code_block('```python\\nprint("hi")\\n```')
        'print("hi")'
    """
    text = text.strip()

    if MARKDOWN_CODE_FENCE not in text:
        return text

    lines = text.splitlines()
    content_lines: list[str] = []
    inside_block = False

    for line in lines:
        if line.strip().startswith(MARKDOWN_CODE_FENCE):
            inside_block = not inside_block
            continue
        if inside_block:
            content_lines.append(line)

    if content_lines:
        result = "\n".join(content_lines).strip()
        logger.info(f"Extracted from code block: {result[:100]}...")
        return result

    logger.info(f"No code block found, returning as-is: {text[:100]}...")
    return text


def extract_json_from_text(text: str) -> Optional[str]:
    """
    Extract first valid JSON object from text containing mixed content.

    Tries multiple strategies in order:
    1. Look for explicitly marked JSON blocks (<<<JSON ... JSON>>>)
    2. Look for embedded JSON objects ({ ... })
    3. Fallback: Try parsing entire text as JSON

    Args:
        text: Input text possibly containing JSON mixed with other content

    Returns:
        First valid JSON object found, or None if no valid JSON

    Example:
        >>> extract_json_from_text('Some text {"key": "value"} more text')
        '{"key": "value"}'
    """
    # Strategy 1: Look for explicitly marked JSON block
    json_start = text.find("<<<JSON")
    if json_start != -1:
        json_end = text.find("JSON>>>", json_start)
        if json_end != -1:
            marked = text[json_start + 7:json_end].strip()
            try:
                json.loads(marked)
                logger.info(f"Extracted JSON from marked block (<<<JSON...JSON>>>)")
                return marked
            except json.JSONDecodeError:
                logger.warning("Marked JSON block found but invalid JSON")
                pass

    # Strategy 2: Look for JSON objects in the text
    start_idx = text.find("{")
    if start_idx != -1:
        brace_count = 0
        for end_idx in range(start_idx, len(text)):
            char = text[end_idx]
            brace_count += (char == "{") - (char == "}")

            if brace_count == 0:
                candidate = text[start_idx : end_idx + 1]
                try:
                    parsed = json.loads(candidate)
                    # Prefer JSON objects that contain the top-level 'tasks' key
                    if isinstance(parsed, dict) and "tasks" in parsed:
                        logger.info(f"Extracted valid JSON with 'tasks' from position {start_idx}-{end_idx}")
                        return candidate
                    # If the parsed JSON is a small/empty object like {}, ignore it
                    if isinstance(parsed, dict) and len(parsed) == 0:
                        continue
                    # Otherwise, accept only reasonably large JSON objects to avoid false positives
                    if len(candidate) > 50:
                        logger.info(f"Extracted valid JSON (no tasks key) from position {start_idx}-{end_idx}")
                        return candidate
                except json.JSONDecodeError:
                    continue

    # Strategy 3: Try parsing entire text as JSON (in case it's pure JSON with no extra text)
    try:
        parsed = json.loads(text.strip())
        if isinstance(parsed, dict) and ("tasks" in parsed or len(parsed) > 0):
            logger.info("Parsed entire text as valid JSON")
            return text.strip()
    except json.JSONDecodeError:
        pass

    logger.warning(f"No valid JSON object found in text. First 300 chars: {text[:300]!r}")
    return None


def truncate_for_logging(text: str, max_length: int = 300) -> str:
    """
    Truncate text for safe logging output.

    Args:
        text: Text to truncate
        max_length: Maximum length before truncation

    Returns:
        Truncated text with ellipsis if needed
    """
    if len(text) <= max_length:
        return text
    return text[:max_length] + f"... [truncated, full length: {len(text)}]"
    
    return None
