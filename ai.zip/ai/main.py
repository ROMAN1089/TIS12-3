"""Main application entry point."""

import logging

import uvicorn
from fastapi import FastAPI, HTTPException, Header

from agent.config import config
from agent.models import AgentRequest, AgentResponse
from agent.services import S3Service, OllamaService, GeneratorService
from agent.utils.prompts import SystemPrompts

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title=f"AI Agent: {config.service_role}",
    description="Multi-agent system with S3 backend for artifact storage",
    version="2.0.0"
)

# Initialize services
s3_service = S3Service()
ollama_service = OllamaService()
generator_service = GeneratorService(ollama_service)


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "role": config.service_role,
        "model": config.ollama_model,
    }


@app.post("/generate", response_model=AgentResponse)
async def generate_task(
    request: AgentRequest,
    x_service_token: str = Header(None)
):
    """
    Generate content based on agent role.
    
    Roles:
    - decomposer: Break down tasks into subtasks (JSON)
    - db_architect: Generate SQLAlchemy models (Python)
    - coder: Generate production-ready code (Python)
    - generic: General text generation
    """
    # Validate authentication
    if x_service_token != config.api_token:
        raise HTTPException(status_code=401, detail="Invalid Service Token")
    
    # Build full prompt with optional S3 contexts
    full_input_context = ""
    if request.context_keys:
        for key, ref in request.context_keys.items():
            logger.info(f"Downloading context '{key}' from {ref}...")
            file_content = s3_service.download_content(ref)
            full_input_context += f"\n\n--- CONTEXT ({key}) ---\n{file_content}\n"
    
    final_user_prompt = (request.input_data or "").strip() + full_input_context
    
    # Determine system prompt and modes
    if request.system_prompt_override:
        system_prompt = request.system_prompt_override
        # Use role to determine modes even with override
        is_code_mode = config.service_role in ("coder", "db_architect")
        is_json_mode = config.service_role == "decomposer"
        file_extension = "json" if is_json_mode else ("py" if is_code_mode else "txt")
    else:
        system_prompt, is_code_mode, is_json_mode, file_extension = SystemPrompts.build_for_role(
            config.service_role
        )
    
    try:
        # Generate content with retry logic
        generated_content, retries_used = generator_service.generate_with_retry(
            system_prompt=system_prompt,
            user_prompt=final_user_prompt,
            is_code=is_code_mode,
            is_json=is_json_mode,
        )
        
        # Upload to S3
        artifact = s3_service.upload_artifact(
            content=generated_content,
            extension=file_extension,
            role=config.service_role
        )
        
        return AgentResponse(
            status="success",
            artifact=artifact,
            metadata={
                "model": config.ollama_model,
                "role": config.service_role,
                "retries_used": retries_used,
                "max_retries": config.max_retries,
                "ollama_host": config.ollama_host,
            },
        )
    except Exception as e:
        logger.error(f"Process failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


def main():
    """Run the application."""
    logger.info(f"Starting AI Agent: {config.service_role}")
    logger.info(f"Using model: {config.ollama_model}")
    logger.info(f"Ollama host: {config.ollama_host}")
    logger.info(f"S3 endpoint: {config.s3_endpoint}")
    
    uvicorn.run(
        app,
        host=config.host,
        port=config.port,
        log_level="info"
    )


if __name__ == "__main__":
    main()
