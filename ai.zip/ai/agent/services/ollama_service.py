"""Ollama LLM service for generation."""

import logging
from typing import Dict, Any, List

import ollama

from agent.config import config

logger = logging.getLogger(__name__)


class OllamaService:
    """Service for interacting with Ollama LLM."""
    
    def __init__(self):
        """Initialize Ollama client."""
        self.client = ollama.Client(host=config.ollama_host)
        self.model = config.ollama_model
    
    def chat(self, messages: List[Dict[str, str]], force_json: bool = False) -> str:
        """
        Send chat request to Ollama.
        
        Args:
            messages: List of message dicts with 'role' and 'content'
            force_json: Whether to force JSON output (not used due to model issues)
        
        Returns:
            Generated content as string
        """
        kwargs: Dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "options": {
                "temperature": config.ollama_temperature,
                "num_predict": config.ollama_num_predict,
            },
        }
        
        # NOTE: format="json" often causes issues with some models (like GPT).
        # Instead, we rely on extract_json_from_text() to find valid JSON in the response.
        # Uncomment below ONLY if your model properly supports format="json"
        # if force_json:
        #     kwargs["format"] = "json"
        
        try:
            resp = self.client.chat(**kwargs)
            content = resp["message"]["content"]
            
            logger.info(f"Raw Ollama response (length={len(content)}): {content[:300]}...")
            if len(content) > 3000:
                logger.info(f"... [truncated, full length: {len(content)}]")
            else:
                logger.info(f"Full response: {content}")
            
            return content
        except Exception as e:
            logger.error(f"Ollama chat failed: {e}")
            raise
