"""S3 storage service for artifact management."""

import io
import uuid
import logging
from typing import Tuple
from datetime import datetime

import boto3
from botocore.exceptions import ClientError
from fastapi import HTTPException

from agent.config import config
from agent.models import AgentArtifact

logger = logging.getLogger(__name__)


class S3Service:
    """Service for managing S3 storage operations."""
    
    def __init__(self):
        """Initialize S3 client and ensure bucket exists."""
        self.client = boto3.client(
            "s3",
            endpoint_url=config.s3_endpoint,
            aws_access_key_id=config.s3_access_key,
            aws_secret_access_key=config.s3_secret_key,
            region_name=config.s3_region,
        )
        self.bucket = config.s3_bucket
        self._ensure_bucket_exists()
    
    def _ensure_bucket_exists(self) -> None:
        """Ensure the S3 bucket exists, create if necessary."""
        try:
            self.client.head_bucket(Bucket=self.bucket)
            logger.info(f"Connected to S3 bucket: {self.bucket}")
        except ClientError:
            logger.warning(f"Bucket {self.bucket} not accessible. Attempting to create...")
            try:
                self.client.create_bucket(Bucket=self.bucket)
                logger.info(f"Created bucket: {self.bucket}")
            except Exception as e:
                logger.error(f"Failed to create bucket: {e}")
                raise
    
    def parse_s3_ref(self, ref: str) -> Tuple[str, str]:
        """
        Parse S3 reference into bucket and key.
        
        Accepts:
          - s3://bucket/key
          - bucket/key
          - key (uses default bucket)
        
        Returns:
            Tuple of (bucket, key)
        """
        ref = ref.strip()
        
        if ref.startswith("s3://"):
            no_scheme = ref[len("s3://"):]
            parts = no_scheme.split("/", 1)
            if len(parts) != 2 or not parts[0] or not parts[1]:
                raise ValueError(f"Invalid s3:// ref: {ref}")
            return parts[0], parts[1]
        
        if "/" in ref and not ref.startswith("/"):
            first, rest = ref.split("/", 1)
            if first == self.bucket:
                return first, rest
            return self.bucket, ref
        
        return self.bucket, ref
    
    def download_content(self, ref: str) -> str:
        """
        Download content from S3 by reference.
        
        Args:
            ref: S3 reference (s3://bucket/key or key)
        
        Returns:
            Content as string
        """
        try:
            bucket, key = self.parse_s3_ref(ref)
            obj = self.client.get_object(Bucket=bucket, Key=key)
            return obj["Body"].read().decode("utf-8", errors="replace")
        except Exception as e:
            logger.error(f"Failed to download context '{ref}': {e}")
            return ""
    
    def upload_artifact(self, content: str, extension: str, role: str) -> AgentArtifact:
        """
        Upload artifact to S3.
        
        Args:
            content: Content to upload
            extension: File extension (json, py, txt)
            role: Agent role for folder organization
        
        Returns:
            AgentArtifact with S3 details
        """
        unique_id = uuid.uuid4().hex[:8]
        timestamp = datetime.now().strftime("%Y%m%d")
        filename = f"{role}/{timestamp}_{unique_id}.{extension}"
        
        file_obj = io.BytesIO(content.encode("utf-8"))
        
        try:
            self.client.upload_fileobj(file_obj, self.bucket, filename)
            url = self.client.generate_presigned_url(
                "get_object",
                Params={"Bucket": self.bucket, "Key": filename},
                ExpiresIn=3600,
            )
            logger.info(f"Artifact uploaded: {filename}")
            
            return AgentArtifact(
                s3_key=filename,
                s3_url=url,
                content_type=extension,
                filename=filename,
            )
        except Exception as e:
            logger.error(f"S3 Upload Failed: {e}")
            raise HTTPException(
                status_code=500,
                detail=f"S3 Storage Error: {str(e)}"
            )
