"""Generator service for content creation with retry logic."""

import logging
from typing import Tuple, List, Dict

from agent.config import config
from agent.services.ollama_service import OllamaService
from agent.utils.text_utils import clean_code_block, extract_json_from_text
from agent.utils.validators import PythonValidator, JSONValidator
from agent.utils.prompts import SystemPrompts

logger = logging.getLogger(__name__)


class GeneratorService:
    """Service for generating content with self-correction."""
    
    def __init__(self, ollama_service: OllamaService):
        """
        Initialize generator service.
        
        Args:
            ollama_service: Ollama service instance
        """
        self.ollama = ollama_service
        self.max_retries = config.max_retries
    
    def generate_with_retry(
        self,
        system_prompt: str,
        user_prompt: str,
        is_code: bool,
        is_json: bool
    ) -> Tuple[str, int]:
        """
        Generate content with automatic retry and self-correction.
        
        Args:
            system_prompt: System prompt defining agent behavior
            user_prompt: User's request/task description
            is_code: Whether output should be Python code
            is_json: Whether output should be JSON
        
        Returns:
            Tuple of (final_content, retries_used)
        """
        messages: List[Dict[str, str]] = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]
        
        last_clean = ""
        retries_used = 0
        
        logger.info(f"Starting generation: is_code={is_code}, is_json={is_json}")
        
        for attempt in range(0, max(1, self.max_retries + 1)):
            logger.info(f"Generation attempt {attempt + 1}/{self.max_retries + 1}...")
            
            # Generate content
            raw = self.ollama.chat(messages, force_json=is_json)
            clean = clean_code_block(raw)
            last_clean = clean
            
            # Handle JSON mode
            if is_json:
                # Try to extract valid JSON from potentially dirty response
                extracted = extract_json_from_text(clean)
                if extracted:
                    logger.info("Extracted JSON from response")
                    clean = extracted
                
                ok, err, normalized = JSONValidator.validate_decomposer_output(clean)
                if ok and normalized is not None:
                    logger.info(f"✓ JSON validation passed on attempt {attempt + 1}")
                    if attempt > 0:
                        retries_used = attempt
                    return normalized, retries_used
                
                logger.warning(f"✗ JSON validation failed: {err}")
                
                if attempt >= self.max_retries:
                    logger.error(f"Max retries ({self.max_retries}) reached for JSON. Last response:\n{clean}")
                    break
                
                # Add correction prompt
                fix_prompt = SystemPrompts.get_json_fix_prompt(err)
                messages.append({"role": "assistant", "content": raw})
                messages.append({"role": "user", "content": fix_prompt})
                continue
            
            # Handle code mode
            if is_code:
                lint = PythonValidator.validate(clean)
                if lint == "PASS":
                    logger.info(f"✓ Python validation passed on attempt {attempt + 1}")
                    if attempt > 0:
                        retries_used = attempt
                    return clean, retries_used
                
                logger.warning(f"✗ Python validation failed: {lint}")
                
                if attempt >= self.max_retries:
                    logger.error(f"Max retries ({self.max_retries}) reached for Python. Last response:\n{clean}")
                    break
                
                # Add correction prompt
                fix_prompt = SystemPrompts.get_python_fix_prompt(lint)
                messages.append({"role": "assistant", "content": raw})
                messages.append({"role": "user", "content": fix_prompt})
                continue
            
            # Generic text mode (no validation needed)
            if attempt > 0:
                retries_used = attempt
            return clean, retries_used
        
        logger.error("Max retries reached. Returning last attempt (may be invalid).")
        return last_clean, self.max_retries
