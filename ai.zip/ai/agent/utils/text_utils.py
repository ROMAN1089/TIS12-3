"""Text processing utilities."""

import json
import logging
from typing import Optional, List

logger = logging.getLogger(__name__)


def clean_code_block(text: str) -> str:
    """
    Extract raw content from markdown fenced blocks, if present.
    
    Args:
        text: Input text possibly containing markdown code blocks
    
    Returns:
        Cleaned text without markdown formatting
    """
    text = text.strip()
    
    if "```" not in text:
        return text
    
    lines = text.splitlines()
    buf: List[str] = []
    in_block = False
    
    for line in lines:
        if line.strip().startswith("```"):
            in_block = not in_block
            continue
        if in_block:
            buf.append(line)
    
    if buf:
        result = "\n".join(buf).strip()
        logger.info(f"Extracted from code block: {result[:100]}...")
        return result
    
    logger.info(f"No code block found, returning as-is: {text[:100]}...")
    return text


def extract_json_from_text(text: str) -> Optional[str]:
    """
    Try to extract valid JSON object from text that may contain garbage,
    explanations, or multiple JSON fragments.
    
    This function scans for the first complete JSON object (matching braces)
    and validates it before returning.
    
    Args:
        text: Input text possibly containing JSON mixed with other content
    
    Returns:
        First valid JSON object found, or None
    """
    # Try to find JSON object patterns { ... }
    start_idx = text.find('{')
    if start_idx == -1:
        return None
    
    # Try progressively longer substrings starting from the first {
    bracket_count = 0
    for end_idx in range(start_idx, len(text)):
        char = text[end_idx]
        if char == '{':
            bracket_count += 1
        elif char == '}':
            bracket_count -= 1
            if bracket_count == 0:
                # Found a complete JSON object
                candidate = text[start_idx:end_idx + 1]
                try:
                    json.loads(candidate)
                    logger.info(f"Extracted valid JSON from position {start_idx}-{end_idx}")
                    return candidate
                except json.JSONDecodeError:
                    continue
    
    return None
