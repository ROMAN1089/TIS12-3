"""Validators for Python code and JSON output."""

import ast
import json
import logging
from typing import Tuple, Optional

from pydantic import ValidationError

from agent.models import DecomposerOutput

logger = logging.getLogger(__name__)


class PythonValidator:
    """Validator for Python code syntax."""
    
    @staticmethod
    def validate(code: str) -> str:
        """
        Validate Python code syntax.
        
        Args:
            code: Python code to validate
        
        Returns:
            "PASS" if valid, error message otherwise
        """
        try:
            ast.parse(code)
            return "PASS"
        except SyntaxError as e:
            return f"SYNTAX_ERROR: Line {e.lineno}: {e.msg}\nCode: {e.text}"
        except Exception as e:
            return f"ERROR: {str(e)}"


class JSONValidator:
    """Validator for JSON output conforming to schemas."""
    
    ALLOWED_EXECUTION_AGENTS = {"db_architect", "coder"}
    
    @staticmethod
    def validate_decomposer_output(raw_text: str) -> Tuple[bool, str, Optional[str]]:
        """
        Validate JSON against DecomposerOutput execution-plan schema.
        
        Checks:
        - JSON is parseable
        - Schema matches DecomposerOutput
        - Dependencies refer to existing task IDs
        - No obvious truncation patterns
        
        Args:
            raw_text: Raw JSON text to validate
        
        Returns:
            Tuple of (is_valid, error_message, normalized_json)
        """
        logger.info(f"Validating JSON (length={len(raw_text)}): {raw_text[:150]}...")
        
        # Check for obvious truncation patterns
        if raw_text.count('"...') > 2 or raw_text.endswith('...'):
            logger.error("JSON appears to be truncated (contains '...' placeholders)")
            return False, "JSON_TRUNCATION: Response appears to be truncated with '...' placeholders", None
        
        if raw_text.count('.') > 10 and raw_text.endswith('.'):
            logger.error("JSON appears to be truncated (ends with many dots)")
            return False, "JSON_TRUNCATION: Response appears truncated (ends with dots)", None
        
        # Parse JSON
        try:
            data = json.loads(raw_text)
        except json.JSONDecodeError as e:
            logger.error(f"JSON parse error at line {e.lineno}, col {e.colno}: {e.msg}")
            return False, f"JSON_ERROR: {e.msg} at line {e.lineno}, column {e.colno}", None
        
        # Validate against schema
        try:
            obj = DecomposerOutput.model_validate(data)
        except ValidationError as e:
            logger.error(f"Schema validation error: {str(e)}")
            return False, f"SCHEMA_ERROR: {str(e)}", None
        
        # Check that dependencies reference existing IDs
        ids = {t.id for t in obj.tasks}
        for task in obj.tasks:
            if task.agent not in JSONValidator.ALLOWED_EXECUTION_AGENTS:
                logger.error(
                    "Invalid agent '%s'. Allowed agents: %s",
                    task.agent,
                    ", ".join(sorted(JSONValidator.ALLOWED_EXECUTION_AGENTS)),
                )
                return (
                    False,
                    "AGENT_ERROR: invalid agent '%s'. Allowed agents: %s"
                    % (task.agent, ", ".join(sorted(JSONValidator.ALLOWED_EXECUTION_AGENTS))),
                    None,
                )
            for dep in task.dependencies:
                if dep not in ids:
                    logger.error(f"Dependency error: task '{task.id}' depends on unknown id '{dep}'")
                    return False, f"DEPENDENCY_ERROR: task '{task.id}' depends on unknown id '{dep}'", None
        
        normalized = json.dumps(obj.model_dump(), ensure_ascii=False)
        logger.info(f"JSON validation passed. Tasks: {len(obj.tasks)}")
        return True, "PASS", normalized
