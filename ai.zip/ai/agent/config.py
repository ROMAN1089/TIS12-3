"""Configuration management for the AI agent."""

import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


@dataclass
class Config:
    """Application configuration."""
    
    # Agent settings
    service_role: str = os.getenv("AGENT_ROLE", "generic")
    api_token: str = os.getenv("AGENT_SECRET_TOKEN", "change_me")
    max_retries: int = int(os.getenv("MAX_SELF_CORRECTION_RETRIES", "3"))
    
    # Ollama settings
    ollama_model: str = os.getenv("OLLAMA_MODEL", "llama3")
    ollama_host: str = os.getenv("OLLAMA_HOST", "http://localhost:11434")
    ollama_temperature: float = float(os.getenv("OLLAMA_TEMPERATURE", "0"))
    ollama_num_predict: int = int(os.getenv("OLLAMA_NUM_PREDICT", "2048"))
    
    # S3/MinIO settings
    s3_endpoint: str = os.getenv("S3_ENDPOINT", "http://localhost:9000")
    s3_access_key: str = os.getenv("S3_ACCESS_KEY", "minioadmin")
    s3_secret_key: str = os.getenv("S3_SECRET_KEY", "minioadmin")
    s3_bucket: str = os.getenv("S3_BUCKET", "agent-artifacts")
    s3_region: str = os.getenv("S3_REGION", "us-east-1")
    
    # Server settings
    port: int = int(os.getenv("PORT", "8000"))
    host: str = os.getenv("HOST", "0.0.0.0")


# Global config instance
config = Config()
