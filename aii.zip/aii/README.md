# AI Agent System

Многоагентная система с поддержкой различных ролей и хранилищем артефактов в S3/MinIO.

## Структура проекта

```
.
├── app/
│   ├── __init__.py
│   ├── config.py              # Конфигурация приложения
│   ├── models/                # Модели данных
│   │   ├── __init__.py
│   │   └── schemas.py         # Pydantic схемы
│   ├── services/              # Бизнес-логика
│   │   ├── __init__.py
│   │   ├── s3_service.py      # Работа с S3/MinIO
│   │   ├── ollama_service.py  # Интеграция с Ollama
│   │   └── generator_service.py  # Генерация с retry-логикой
│   └── utils/                 # Утилиты
│       ├── __init__.py
│       ├── validators.py      # Валидаторы (Python, JSON)
│       ├── text_utils.py      # Обработка текста
│       └── prompts.py         # Системные промпты
├── main.py                    # Точка входа
├── newMain.py                 # Старая версия (можно удалить)
├── requirements.txt
└── README.md
```

## Роли агентов

### 1. Decomposer
Разбивает задачи на подзадачи. Возвращает JSON со списком задач.

**Пример запроса:**
```bash
AGENT_ROLE=decomposer OLLAMA_MODEL=llama3 python3 main.py
```

### 2. DB Architect
Генерирует SQLAlchemy модели для баз данных.

**Пример запроса:**
```bash
AGENT_ROLE=db_architect OLLAMA_MODEL=llama3 python3 main.py
```

### 3. Coder
Генерирует production-ready Python код.

**Пример запроса:**
```bash
AGENT_ROLE=coder OLLAMA_MODEL=llama3 python3 main.py
```

### 4. Generic
Универсальный помощник для текстовых задач.

## Переменные окружения

Создайте файл `.env`:

```env
# Роль агента
AGENT_ROLE=decomposer

# Токен безопасности
AGENT_SECRET_TOKEN=23242324

# Настройки Ollama
OLLAMA_MODEL=llama3
OLLAMA_HOST=http://localhost:11434
OLLAMA_TEMPERATURE=0
OLLAMA_NUM_PREDICT=2048

# Настройки S3/MinIO
S3_ENDPOINT=http://localhost:9000
S3_ACCESS_KEY=minioadmin
S3_SECRET_KEY=minioadmin
S3_BUCKET=agent-artifacts
S3_REGION=us-east-1

# Настройки сервера
PORT=8001
HOST=0.0.0.0

# Retry логика
MAX_SELF_CORRECTION_RETRIES=3
```

## Установка и запуск

### 1. Установка зависимостей

```bash
pip install -r requirements.txt
```

### 2. Запуск агента

```bash
AGENT_ROLE=decomposer OLLAMA_MODEL=llama3 python3 main.py
```

### 3. Пример API запроса

```bash
curl -X POST "http://localhost:8001/generate" \
  -H "Content-Type: application/json" \
  -H "x-service-token: 23242324" \
  -d '{
    "input_data": "create API for ecommerce"
  }'
```

### 4. С контекстом из S3

```bash
curl -X POST "http://localhost:8001/generate" \
  -H "Content-Type: application/json" \
  -H "x-service-token: 23242324" \
  -d '{
    "input_data": "implement the database models",
    "context_keys": {
      "spec": "decomposer/20260218_abc123.json"
    }
  }'
```

## API Endpoints

### `GET /health`
Проверка состояния агента.

**Ответ:**
```json
{
  "status": "healthy",
  "role": "decomposer",
  "model": "llama3"
}
```

### `POST /generate`
Генерация контента на основе роли агента.

**Заголовки:**
- `x-service-token`: Токен аутентификации

**Тело запроса:**
```json
{
  "input_data": "описание задачи",
  "context_keys": {
    "key": "s3_reference"
  },
  "system_prompt_override": "optional custom prompt"
}
```

**Ответ:**
```json
{
  "status": "success",
  "artifact": {
    "s3_key": "decomposer/20260218_abc123.json",
    "s3_url": "https://...",
    "content_type": "json",
    "filename": "decomposer/20260218_abc123.json"
  },
  "metadata": {
    "model": "llama3",
    "role": "decomposer",
    "retries_used": 0,
    "max_retries": 3,
    "ollama_host": "http://localhost:11434"
  }
}
```

## Архитектурные улучшения

### ✅ Модульность
- Разделение на сервисы (S3, Ollama, Generator)
- Утилиты вынесены в отдельные модули
- Четкое разделение ответственности

### ✅ Читаемость
- Docstrings для всех классов и функций
- Type hints везде
- Логирование с контекстом

### ✅ Расширяемость
- Легко добавить новые роли агентов
- Промпты централизованы в одном месте
- Валидаторы расширяемы

### ✅ Надежность
- Retry логика с валидацией
- Извлечение JSON из "грязных" ответов
- Подробное логирование ошибок

## Тестирование других агентов

```bash
# DB Architect
AGENT_ROLE=db_architect OLLAMA_MODEL=llama3 python3 main.py

curl -X POST "http://localhost:8001/generate" \
  -H "Content-Type: application/json" \
  -H "x-service-token: 23242324" \
  -d '{
    "input_data": "Create models for ecommerce: User, Product, Order"
  }'

# Coder
AGENT_ROLE=coder OLLAMA_MODEL=llama3 python3 main.py

curl -X POST "http://localhost:8001/generate" \
  -H "Content-Type: application/json" \
  -H "x-service-token: 23242324" \
  -d '{
    "input_data": "Create FastAPI endpoint for user registration"
  }'
```

## Что дальше?

1. Добавить unit-тесты для каждого модуля
2. Добавить Docker Compose для локального развертывания
3. Добавить метрики и мониторинг
4. Добавить rate limiting
5. Добавить кэширование результатов
