"""Main application entry point with clean architecture."""

import logging
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, HTTPException, Header

from agent.config import config
from agent.constants import AgentRole
from agent.exceptions import (
    AuthenticationError,
    MaxRetriesExceededError,
    S3Error,
    OllamaError,
    AgentException,
)
from agent.models import AgentRequest, AgentResponse
from agent.services import S3Service, OllamaService, GeneratorService
from agent.utils.prompts import SystemPrompts

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

# Service container
_services: dict = {}


def get_services() -> dict:
    """Get or initialize service container."""
    global _services
    if not _services:
        _services["ollama"] = OllamaService(config)
        _services["s3"] = S3Service(config)
        _services["generator"] = GeneratorService(
            _services["ollama"],
            config,
        )
    return _services


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan context manager."""
    logger.info(f"Starting AI Agent: {config.agent.role}")
    logger.info(f"Using model: {config.ollama.model}")
    logger.info(f"Ollama host: {config.ollama.host}")
    logger.info(f"S3 endpoint: {config.s3.endpoint}")
    yield
    # Cleanup if needed
    logger.info("Shutting down AI Agent")


# Initialize FastAPI app
app = FastAPI(
    title=f"AI Agent: {config.agent.role}",
    description="Multi-agent orchestration system with S3 artifact storage",
    version="2.0.0",
    lifespan=lifespan,
)


@app.get("/health")
async def health_check() -> dict:
    """Health check endpoint."""
    return {
        "status": "healthy",
        "role": config.agent.role,
        "model": config.ollama.model,
    }


@app.post("/generate", response_model=AgentResponse)
async def generate_task(
    request: AgentRequest,
    x_service_token: str = Header(None),
) -> AgentResponse:
    """
    Generate content based on agent role.

    Roles:
    - decomposer: Break down tasks into subtasks (JSON)
    - db_architect: Generate SQLAlchemy models (Python)
    - coder: Generate production-ready code (Python)
    - generic: General text generation
    """
    services = get_services()

    # Validate authentication
    if x_service_token != config.agent.api_token:
        logger.warning("Invalid authentication token provided")
        raise HTTPException(status_code=401, detail="Invalid Service Token")

    try:
        # Build full prompt with contexts
        user_prompt = _build_user_prompt(request, services["s3"])

        # Get system prompt based on role
        role = AgentRole(config.agent.role)
        system_prompt, is_code, is_json, extension = SystemPrompts.build_for_role(
            role.value
        )

        # Generate with validation and retry
        generated_content, retries_used = services["generator"].generate_with_retry(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            is_code=is_code,
            is_json=is_json,
        )

        # Upload to S3
        artifact = services["s3"].upload_artifact(
            content=generated_content,
            extension=extension.value,
            role=config.agent.role,
        )

        return AgentResponse(
            status="success",
            artifact=artifact,
            metadata={
                "model": config.ollama.model,
                "role": config.agent.role,
                "retries_used": retries_used,
                "max_retries": config.agent.max_retries,
                "ollama_host": config.ollama.host,
            },
        )

    except AuthenticationError as e:
        logger.warning(f"Authentication failed: {e}")
        raise HTTPException(status_code=401, detail=str(e))
    except MaxRetriesExceededError as e:
        logger.error(f"Generation failed after {e.max_retries} retries: {e.last_error}")
        raise HTTPException(
            status_code=422,
            detail=f"Content generation failed after {e.max_retries} retries",
        )
    except S3Error as e:
        logger.error(f"S3 operation failed: {e}")
        raise HTTPException(status_code=500, detail="Storage operation failed")
    except OllamaError as e:
        logger.error(f"Ollama operation failed: {e}")
        raise HTTPException(status_code=503, detail="LLM service unavailable")
    except AgentException as e:
        logger.error(f"Agent error: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Unexpected error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Internal server error")


def _build_user_prompt(request: AgentRequest, s3_service: S3Service) -> str:
    """
    Build complete user prompt with contexts.

    Args:
        request: Agent request
        s3_service: S3 service for context retrieval

    Returns:
        Complete user prompt with contexts appended
    """
    base_prompt = (request.input_data or "").strip()

    if not request.context_keys:
        return base_prompt

    context_parts = [base_prompt]
    for key, ref in request.context_keys.items():
        try:
            logger.info(f"Downloading context '{key}' from {ref}...")
            file_content = s3_service.download_content(ref)
            context_parts.append(f"\n\n--- CONTEXT ({key}) ---\n{file_content}")
        except Exception as e:
            logger.warning(f"Failed to download context '{key}': {e}")

    return "".join(context_parts)


def main() -> None:
    """Run the application."""
    try:
        uvicorn.run(
            app,
            host=config.server.host,
            port=config.server.port,
            log_level="info",
        )
    except Exception as e:
        logger.error(f"Failed to start server: {e}", exc_info=True)
        raise


if __name__ == "__main__":
    main()
